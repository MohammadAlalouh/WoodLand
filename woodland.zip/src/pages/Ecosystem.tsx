import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Volume2 } from "lucide-react";
import { toast } from "sonner";
import streamImage from "@/assets/ecosystem-stream.jpg";
import wildlifeImage from "@/assets/ecosystem-wildlife.jpg";
import oldgrowthImage from "@/assets/ecosystem-oldgrowth.jpg";

const Ecosystem = () => {
  const ecosystems = [
    {
      title: "Forest Streams",
      image: streamImage,
      description:
        "Crystal-clear streams flowing through our woodlands provide vital habitat for countless species. These waterways support diverse aquatic life, filter nutrients, and connect forest ecosystems. The moss-covered rocks and ferns along the banks create microhabitats essential for amphibians and insects.",
    },
    {
      title: "Wildlife Corridors",
      image: wildlifeImage,
      description:
        "Our forests serve as crucial corridors for wildlife movement, allowing species like deer, bears, and countless birds to migrate safely. These pathways maintain genetic diversity and enable animals to access food, water, and breeding grounds across vast landscapes.",
    },
    {
      title: "Old-Growth Forests",
      image: oldgrowthImage,
      description:
        "Ancient trees in old-growth forests are irreplaceable treasures, some standing for centuries. These giants support complex ecosystems, storing massive amounts of carbon and providing homes for countless organisms. Their preservation is critical for biodiversity and climate stability.",
    },
  ];

  const handleTextToSpeech = (text: string, title: string) => {
    if ("speechSynthesis" in window) {
      // Cancel any ongoing speech
      window.speechSynthesis.cancel();

      const utterance = new SpeechSynthesisUtterance(`${title}. ${text}`);
      utterance.rate = 0.9;
      utterance.pitch = 1;
      utterance.volume = 1;

      window.speechSynthesis.speak(utterance);
      toast.success("Playing audio description");
    } else {
      toast.error("Text-to-speech is not supported in your browser");
    }
  };

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12 animate-fade-in">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Our Ecosystem</h1>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Explore the diverse habitats and natural wonders within our conservation areas. 
            Click the speaker icon to hear audio descriptions.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {ecosystems.map((eco, index) => (
            <Card
              key={index}
              className="overflow-hidden shadow-medium hover:shadow-strong transition-all duration-300 animate-slide-up"
              style={{ animationDelay: `${index * 150}ms` }}
            >
              <img
                src={eco.image}
                alt={eco.title}
                className="w-full h-80 object-cover"
              />
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <h2 className="text-2xl font-bold">{eco.title}</h2>
                  <Button
                    size="icon"
                    variant="outline"
                    onClick={() => handleTextToSpeech(eco.description, eco.title)}
                    className="hover:bg-accent hover:text-accent-foreground"
                    aria-label={`Listen to ${eco.title} description`}
                  >
                    <Volume2 className="w-5 h-5" />
                  </Button>
                </div>
                <p className="text-muted-foreground leading-relaxed">
                  {eco.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Additional Info */}
        <div className="mt-16 bg-gradient-forest text-primary-foreground p-8 rounded-xl shadow-medium">
          <h3 className="text-2xl font-bold mb-4 text-center">
            Ecosystem Services
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
            <div>
              <h4 className="font-semibold mb-2">Carbon Storage</h4>
              <p className="text-primary-foreground/90">
                Our forests sequester thousands of tons of CO₂ annually
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Water Filtration</h4>
              <p className="text-primary-foreground/90">
                Natural filtration provides clean water for communities
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Biodiversity</h4>
              <p className="text-primary-foreground/90">
                Home to over 500 species of plants and animals
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Ecosystem;
