import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Upload } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

interface UploadedImage {
  id: string;
  url: string;
  name: string;
  email: string;
  timestamp: number;
}

const Gallery = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
  });
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadedImages, setUploadedImages] = useState<UploadedImage[]>([]);
  const [previewUrl, setPreviewUrl] = useState<string>("");

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const validTypes = ["image/jpeg", "image/jpg", "image/png", "image/gif"];
      if (!validTypes.includes(file.type)) {
        toast.error("Please upload only image files (.jpg, .jpeg, .png, .gif)");
        return;
      }

      setSelectedFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name || !formData.email || !selectedFile) {
      toast.error("Please fill in all fields and select an image");
      return;
    }

    // Simulate AI validation (in production, this would call an actual API)
    toast.loading("Validating image...");
    
    setTimeout(() => {
      // Simulate validation success
      const isNatureRelated = true; // In production, this would be the AI response

      if (!isNatureRelated) {
        toast.error("Image must be nature-related. Please upload a different image.");
        return;
      }

      const newImage: UploadedImage = {
        id: Date.now().toString(),
        url: previewUrl,
        name: formData.name,
        email: formData.email,
        timestamp: Date.now(),
      };

      setUploadedImages([newImage, ...uploadedImages]);
      toast.success("Image uploaded successfully!");
      
      // Reset form
      setFormData({ name: "", email: "" });
      setSelectedFile(null);
      setPreviewUrl("");
    }, 1500);
  };

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12 animate-fade-in">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Photo Gallery</h1>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Share your nature photography with our community. All uploads are verified to ensure they showcase the beauty of our natural world.
          </p>
        </div>

        {/* Upload Form */}
        <div className="max-w-2xl mx-auto mb-16">
          <Card className="shadow-medium">
            <CardContent className="p-8">
              <h2 className="text-2xl font-bold mb-6 text-center">Upload Your Nature Photo</h2>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <Label htmlFor="uploaderName">Your Name</Label>
                  <Input
                    id="uploaderName"
                    type="text"
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                    placeholder="John Doe"
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="uploaderEmail">Email Address</Label>
                  <Input
                    id="uploaderEmail"
                    type="email"
                    value={formData.email}
                    onChange={(e) =>
                      setFormData({ ...formData, email: e.target.value })
                    }
                    placeholder="john@example.com"
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="imageUpload">Select Image</Label>
                  <div className="mt-1">
                    <Input
                      id="imageUpload"
                      type="file"
                      accept=".jpg,.jpeg,.png,.gif"
                      onChange={handleFileChange}
                      className="cursor-pointer"
                    />
                    <p className="text-sm text-muted-foreground mt-2">
                      Accepted formats: .jpg, .jpeg, .png, .gif
                    </p>
                  </div>
                </div>

                {previewUrl && (
                  <div className="mt-4">
                    <Label>Preview</Label>
                    <img
                      src={previewUrl}
                      alt="Preview"
                      className="mt-2 w-full h-64 object-cover rounded-lg"
                    />
                  </div>
                )}

                <Button
                  type="submit"
                  className="w-full bg-gradient-forest text-primary-foreground"
                >
                  <Upload className="w-5 h-5 mr-2" />
                  Upload Photo
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Gallery Grid */}
        {uploadedImages.length > 0 && (
          <div>
            <h2 className="text-3xl font-bold text-center mb-8">Community Contributions</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {uploadedImages.map((image) => (
                <Card
                  key={image.id}
                  className="overflow-hidden shadow-medium hover:shadow-strong transition-all duration-300 hover:-translate-y-1"
                >
                  <img
                    src={image.url}
                    alt={`Photo by ${image.name}`}
                    className="w-full h-64 object-cover"
                  />
                  <CardContent className="p-4">
                    <p className="font-semibold">{image.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(image.timestamp).toLocaleDateString()}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Gallery;
